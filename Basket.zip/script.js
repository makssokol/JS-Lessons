"use strict";

class Product {
  constructor(name, price) {
    this.name = name;
    this.price = price;
  }
}

let product1 = new Product("Акварель", 1250);
let product2 = new Product("Кисть", 280);
let product3 = new Product("Краски", 780);

let productLine = [product1, product2, product3];

let basket = [];

let purchaseButtons = document.querySelectorAll(".btn-secondary");

purchaseButtons.forEach(function(button) {
  button.addEventListener("click", function(event) {
    let htmlname = event.srcElement.parentElement.dataset.htmlname;
    addToBasket(htmlname);
    addToBasketHTML(basket);
  });
});

function addToBasket(htmlname) {
  let productToAdd = {};
  for (let product of productLine) {
    if (product.name == htmlname) {
      productToAdd = product;
    }
  }
  let indexOfProduct = basket.indexOf(productToAdd);
  if (basket.includes(productToAdd)) {
    basket[indexOfProduct].quantity += 1;
  } else {
    productToAdd.quantity = 1;
    basket.push(productToAdd);
  }
  return basket;
}

function addToBasketHTML(basket) {
  emptyBasketHTML();
  for (let product of basket) {
    let basketEntry = `<tr><td class="product" data-name="${product.name}">${
      product.name
    }</td><td class="quantity">${product.quantity}</td><td>${product.price *
      product.quantity}</td><td><i class="fas fa-trash-alt"></i></td></tr>`;
    document
      .querySelector(".basket-table")
      .insertAdjacentHTML("beforeend", basketEntry);
    startListenForDeletion();
  }
  let footerEntry = `<tr><td colspan="4">Итого: ${calculateTotalSum(
    basket
  )} &#8381;</td></tr>`;
  document
    .querySelector(".footer")
    .insertAdjacentHTML("afterbegin", footerEntry);
}

function emptyBasketHTML() {
  let basket = document.querySelector(".basket-table");
  let footer = document.querySelector(".footer");
  basket.innerHTML = "";
  footer.innerHTML = "";
}

function calculateTotalSum(basket) {
  let totalSum = 0;
  basket.forEach(function(product) {
    totalSum += product.price * product.quantity;
  });
  return totalSum;
}

function startListenForDeletion() {
  let delButtons = document.querySelectorAll(".fa-trash-alt");
  delButtons.forEach(function(button) {
    button.addEventListener("click", function(event) {
      let elementToDelete = event.srcElement.parentNode.parentNode;
      elementToDelete.remove();
      let productToDelete = elementToDelete.firstElementChild.innerText;
      for (let product of basket) {
        if (product.name == productToDelete) {
          for (let i = 0; i < basket.length; i++) {
            if (basket[i] == product) {
              basket.splice(i, 1);
            }
          }
        }
      }
      let footer = document.querySelector(".footer");
      footer.innerHTML = "";
      let footerEntry = `<tr><td colspan="4">Итого: ${calculateTotalSum(
        basket
      )} &#8381;</td></tr>`;
      document
        .querySelector(".footer")
        .insertAdjacentHTML("afterbegin", footerEntry);
    });
  });
}
