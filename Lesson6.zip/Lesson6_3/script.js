"use strict";

class Product {
  constructor(name, price) {
    this.name = name;
    this.price = price;
  }
}

let product1 = new Product("Акварель", 1250);
let product2 = new Product("Кисть", 280);
let product3 = new Product("Краски", 780);

let productLine = [product1, product2, product3];

let basket = [];

let purchaseButtons = document.querySelectorAll(".btn-secondary");

purchaseButtons.forEach(function(button) {
  button.addEventListener("click", function(event) {
    let htmlname = event.srcElement.parentElement.dataset.htmlname;
    addToBasket(htmlname);
    addToBasketHTML(basket, htmlname);
  });
});

function isBasketNotStarted() {
  let header = document.getElementsByTagName("TH");
  return !document.getElementsByClassName("basket-table").contains(header);
}

/*
class BasketEntry {
    constructor (name, price) {
        this.name = name;
        this.price = price;
        this.quantity = 1;
    };
    addQuantity() {
        this.quantity += 1;
    };
};
*/

function addToBasket(htmlname) {
  let productToAdd = {};
  for (let product of productLine) {
    if (product.name == htmlname) {
      productToAdd = product;
    }
  }
  let indexOfProduct = basket.indexOf(productToAdd);
  if (basket.includes(productToAdd)) {
    basket[indexOfProduct].quantity += 1;
  } else {
    productToAdd.quantity = 1;
    basket.push(productToAdd);
  }
  return basket;
}

function addToBasketHTML(basket, htmlname) {
  for (let product of basket) {
    if (product.quantity == 1) {
      let basketEntry = `<tr><td class="product" data-name="${product.name}">${
        product.name
      }</td><td class="quantity">${product.quantity}</td><td>${product.price *
        product.quantity}</td><td><i class="fas fa-trash-alt"></i></td></tr>`;
      let basketFooter = document.querySelector(".footer");
      basketFooter.insertAdjacentHTML("beforebegin", basketEntry);
    } else {
        let productToAddQuantity = document.querySelectorAll(`.product[data-name="${product.name}"]`);
        productToAddQuantity.parentNode.remove();
        let basketEntry = `<tr><td class="product" data-name="${product.name}">${
            product.name
          }</td><td class="quantity">${product.quantity}</td><td>${product.price *
            product.quantity}</td><td><i class="fas fa-trash-alt"></i></td></tr>`;
          let basketFooter = document.querySelector(".footer");
          basketFooter.insertAdjacentHTML("beforebegin", basketEntry);
    }
  }
}

/*

let quantity = 1;
  let basketEntry = `<tr><td class="product" data-name="${name}">${name}</td><td class="quantity">${quantity}</td><td>${price}</td><td><i class="fas fa-trash-alt"></i></td></tr>`;
  let header =
    "<tr><th>Наименование</th><th>Кол-во</th><th>Цена</th><th></th></tr>";
  let basketTable = document.querySelector(".basket-table");
  if (isBasketNotStarted()) {
    basketTable.insertAdjacentHTML("afterbegin", header);
  }
  if (document.querySelector(".product") == null) {
    basketTable.insertAdjacentHTML("beforeend", basketEntry);
  } else {
    quantity++;
    document
      .querySelector(".product")
      .dataset.name[name].querySelector(".quantity").textContent = quantity;
  }
  */
