"use strict";

document.head.insertAdjacentHTML(
  "afterbegin",
  '<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">'
);

let slider = document.querySelector(".slider");

let loadIcon = document.createElement("i");
loadIcon.classList.add("fas", "fa-spinner", "fa-spin");
slider.insertAdjacentElement("afterbegin", loadIcon);

let leftArrow = document.createElement("i");
leftArrow.classList.add("fas", "fa-chevron-circle-left", "slider-leftArrow");
slider.insertAdjacentElement("beforeend", leftArrow);

let rightArrow = document.createElement("i");
rightArrow.classList.add("fas", "fa-chevron-circle-right", "slider-rightArrow");
slider.insertAdjacentElement("beforeend", rightArrow);

window.addEventListener("load", function() {
  leftArrow.addEventListener("click", function() {
    images.setNextLeftImage();
  });
  rightArrow.addEventListener("click", function() {
    images.setNextRightImage();
  });
  images.setSizes();
  images.init();
  loadIcon.style.display = "none";
});

let images = {
  currentIdx: 0,
  slides: [],
  init() {
    this.slides = document.querySelectorAll(".slider-item");
    this.showImageWithCurrentIdx();
  },
  showImageWithCurrentIdx() {
    this.slides[this.currentIdx].classList.remove("hidden-slide");
  },

  hideVisibleImage() {
    this.slides.forEach(function(slide) {
      if (!slide.classList.contains("hidden-slide")) {
        slide.classList.add("hidden-slide");
      }
    });
  },

  setNextLeftImage() {
    //this.hideVisibleImage();
    if (this.currentIdx == 0) {
      this.currentIdx = this.slides.length - 1;
    } else {
      this.currentIdx--;
    }
    this.slides[this.currentIdx].classList.add("animated", "slideInRight");
    setTimeout(() => {
      if (this.currentIdx == this.slides.length - 1) {
        this.showImageWithCurrentIdx();
        this.slides[0].classList.add("hidden-slide");
        this.slides[this.currentIdx].classList.remove(
          "animated",
          "slideInRight"
        );
      } else {
        this.showImageWithCurrentIdx();
        this.slides[this.currentIdx + 1].classList.add("hidden-slide");
        this.slides[this.currentIdx].classList.remove(
          "animated",
          "slideInRight"
        );
      }
    }, 500);
  },

  setNextRightImage() {
    //this.hideVisibleImage();
    if (this.currentIdx == this.slides.length - 1) {
      this.currentIdx = 0;
    } else {
      this.currentIdx++;
    }
    this.slides[this.currentIdx].classList.add("animated", "slideInLeft");
    setTimeout(() => {
      if (this.currentIdx == 0) {
        this.showImageWithCurrentIdx();
        this.slides[this.slides.length - 1].classList.add("hidden-slide");
        this.slides[this.currentIdx].classList.remove(
          "animated",
          "slideInLeft"
        );
      } else {
        this.showImageWithCurrentIdx();
        this.slides[this.currentIdx - 1].classList.add("hidden-slide");
        this.slides[this.currentIdx].classList.remove(
          "animated",
          "slideInLeft"
        );
      }
    }, 500);
  },

  setSizes() {
    let width = slider.getAttribute("data-width");
    let height = slider.getAttribute("data-height");
    if (width !== null && width !== "") {
      slider.style.width = width;
    }
    if (height !== null && height !== "") {
      slider.style.height = height;
    }
  }
};
