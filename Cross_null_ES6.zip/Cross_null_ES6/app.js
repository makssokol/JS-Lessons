let config = {
  rows: 3,
  cols: 3
};

class Board {
  constructor() {
    this.gameTableElement = document.getElementById("game");
    this.config = config;
  }

  renderMap() {
    for (let row = 0; row < this.config.rows; row++) {
      let tr = document.createElement("tr");
      this.gameTableElement.appendChild(tr);
      for (let col = 0; col < this.config.cols; col++) {
        let td = document.createElement("td");
        td.dataset.row = row.toString();
        td.dataset.col = col.toString();
        tr.appendChild(td);
      }
    }
  }
}

let mapValues = [
  ["", "", ""],
  ["", "", ""],
  ["", "", ""]
];

class Win {
  constructor(mapValues) {
    //this.x = x;
    //this.y = y;
    this.config = config;
    this.mapValues = mapValues;
    this.winLines = this.makeWinLines();
    this.lineWon = this.isLineWon(this.winLines);
  }

  makeWinLines() {
    let horLines = this.makeHorizontalLines();
    let vertLines = this.makeVerticalLines();
    let diagLines = this.makeDiagonals();
    let winLines = [];
    winLines.push(horLines, vertLines, diagLines);
    return winLines;
  }

  makeHorizontalLines() {
    let wonHorizontalLines = [];
    for (let j = 0; j < config.cols; j++) {
      let wonLine = [];
      for (let i = 0; i < config.rows; i++) {
        wonLine.push({ x: i, y: j });
      }
      wonHorizontalLines.push(wonLine);
    }
    return wonHorizontalLines;
  }

  makeVerticalLines() {
    let wonVerticalLines = [];
    for (let i = 0; i < config.cols; i++) {
      let wonLine = [];
      for (let j = 0; j < config.rows; j++) {
        wonLine.push({ x: i, y: j });
      }
      wonVerticalLines.push(wonLine);
    }
    return wonVerticalLines;
  }

  makeDiagonals() {
    let wonDiagonal1 = [];
    let wonDiagonal2 = [];
    let wonDiagonal = [];
    for (let i = 0; i < config.cols; i++) {
      wonDiagonal1.push({ x: i, y: i });
    }
    wonDiagonal.push(wonDiagonal1);
    for (let i = 0; i < config.cols; i++) {
      wonDiagonal2.push({ x: i, y: config.cols - i - 1 });
    }
    wonDiagonal.push(wonDiagonal2);
    return wonDiagonal;
  }

  isLineWon(winLines) {
    for (let line of winLines) {
      let value =
        this.mapValues[line[0].y][line[0].x] +
        this.mapValues[line[1].y][line[1].x] +
        this.mapValues[line[2].y][line[2].x];
      if (value === "XXX" || value === "000") {
        return true;
      }
    }
  }
}

class Game {
  constructor() {
    this.status = "playing";
    this.phase = "X";
    this.mapValues = mapValues;
  }
  init(board) {
    this.board = board;
  }

  initEventHandlers() {
    this.board.gameTableElement.addEventListener("click", event =>
      this.cellClickHandler(event)
    );
  }

  cellClickHandler(event) {
    if (!this.isCorrectClick(event)) {
      return;
    }
    this.fillCell(event);
    const win = new Win(mapValues);
    if (win.isLineWon()) {
      this.setStatusStopped();
      this.sayWonPhrase();
    }

    this.togglePhase();
  }

  isCorrectClick(event) {
    return (
      this.isStatusPlaying() &&
      this.isClickByCell(event) &&
      this.isCellEmpty(event)
    );
  }

  isCellEmpty(event) {
    let row = +event.target.dataset.row;
    let col = +event.target.dataset.col;
    return this.mapValues[row][col] === "";
  }

  fillCell(event) {
    let row = +event.target.dataset.row;
    let col = +event.target.dataset.col;
    this.mapValues[row][col] = this.phase;
    event.target.textContent = this.phase;
  }

  isStatusPlaying() {
    return this.status === "playing";
  }

  isClickByCell(event) {
    return event.target.tagName === "TD";
  }

  setStatusStopped() {
    this.status = "stopped";
  }

  sayWonPhrase() {
    let figure = this.phase === "X" ? "Крестики" : "Нолики";
    alert(`${figure} выиграли!`);
  }

  togglePhase() {
    this.phase = this.phase === "X" ? "0" : "X";
  }
}

window.addEventListener("load", () => {
  const board = new Board();
  const game = new Game();
  game.init(board);
  //game.init(win);
  board.renderMap();
  game.initEventHandlers();
});
