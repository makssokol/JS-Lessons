let boardConfig = {
  rows: [1, 2, 3, 4, 5, 6, 7, 8],
  columns: ["A", "B", "C", "D", "E", "F", "G", "H"]
};

function generateRow(cellColor) {
  let rowHTML = "";
  let color = ['white', 'black'];
  for (let i = 0; i < boardConfig.rows.length; i++) {
    if (cellColor == "white") {
      rowHTML += `<td class="${color[i%2]}"></td>`;
    } else {
      rowHTML += `<td class="${color[(i+1)%2]}"></td>`;
    }
  }
  return `<tr>${rowHTML}</tr>`;
}

function generateBoard() {
    let cellColor = ['white', 'black'];
    let boardHTML = '';
    for (let i = 0; i < boardConfig.columns.length; i++) {
        boardHTML += generateRow(cellColor[i%2]);
    };
    return `<table><tbody>${boardHTML}</tbody></table>`
}

function insertColumnWithRowsNumbers() {
    let trs = document.querySelectorAll('tr');
    for (let i = 0; i < boardConfig.rows.length; i++) {
        let tdNamed = `<td>${boardConfig.rows[i]}</td>`;
        trs[i].insertAdjacentHTML('afterbegin', tdNamed);
    };
}

function insertRowWithColumnLetters() {
    let RowWithColumnLetters = '<td></td>';
    for (let i = 0; i < boardConfig.columns.length; i++) {
        RowWithColumnLetters += `<td>${boardConfig.columns[i]}</td>`;
    }
    document.querySelector('tbody').insertAdjacentHTML('beforeend', RowWithColumnLetters);
}

document.body.insertAdjacentHTML("afterbegin", generateBoard());
insertColumnWithRowsNumbers();
insertRowWithColumnLetters();