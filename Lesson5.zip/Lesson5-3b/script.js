'use strict';

const button = document.querySelector('button');
const cross = document.querySelector('.fas');
const block = document.querySelector('.block');


button.addEventListener('click', function(){
    block.classList.remove('magictime', 'puffOut');
    block.classList.add('magictime', 'puffIn')
});

cross.addEventListener('click', function() {
    block.classList.add('magictime', 'puffOut')
   //block.classList.add('closing');
});