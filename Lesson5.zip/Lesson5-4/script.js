'use strict';

const buttons = document.querySelectorAll('button');
for (let i = 0; i < buttons.length; i++) {
    buttons[i].addEventListener('click', function(event){
        clickProcessor(event);
    })
};

function clickProcessor(event) {
    const buttonText = event.target.textContent;
    const currentImage = event.target.previousElementSibling;
    const text = "<p class=\"detailed-text\">Здесь находится подробнейшее описание данного товара</p>"
    if (buttonText == "Подробнее") {
        currentImage.style = 'display: none';
        event.target.parentNode.querySelector('p').insertAdjacentHTML('afterend', text);
        event.target.textContent = "Отмена";
    }
    if (buttonText == "Отмена") {
        event.target.parentNode.querySelector('.detailed-text').remove();
        currentImage.style = 'display: block';
        event.target.textContent = "Подробнее";
    }
}