'use strict';

let button = document.querySelector('button');
let cross = document.querySelector('.fas');
let block = document.querySelector('.block');

button.addEventListener('click', function(){
    block.classList.remove('closing');
});

cross.addEventListener('click', function() {
    block.classList.add('closing');
});