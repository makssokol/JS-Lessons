// список вариантов ответов к вопросам по индексу
const answersVars = { 
    0: ['Java', 'C++', 'Python', 'Ruby'],
    1: ['Марко ван Бастен', 'Гвидо ван Россум', 'Ханс ван Брекелен', 'Ян ван Эйк'],
    2: [17, 18, 19, 20],
    3: [177, 272, 344, 384],
    4: [99.63, 100.00, 100.37, 100.73],
    5: ['Казахстан', 'Малайзия', 'Россия', 'Латвия'],
};

// список правильных вариантов ответа
const correctAnswers = {
    0: answersVars[0][2],
    1: answersVars[1][1],
    2: answersVars[2][3],
    3: answersVars[3][3],
    4: answersVars[4][0],
    5: answersVars[5][1],
};

let answerVarsForPlayer = { //возвращает список предлагаемых ответов  
    answerVarGenerator(question){
        return answersVars(questionRep.indexOf(question));
    }
};

function answerChecker (userAnswer) { // сверяет ответ пользователя и правильный. Возвращает true/false.
    let correctAnswerIndex = answersVars[qInd].indexOf(correctAnswers.qInd);
    return ((userAnswer - 1) == correctAnswerIndex);
}