let qNum = 0; // номер выводимого вопроса
let qTotalNum = +prompt('На сколько вопросов Вы хотите ответить? (от 1 до 6)'); // получаем количество вопросов, на которые будет отвечать игрок

let game = {
  run() {
    while (qNum < qTotalNum) {
        let questionForPlayer = qGenerator(qNum); // определяется номер вопроса из списка вопросов, на которые будет отвечать игрок
        alert('Внимание вопрос: ' + questionRep[questionForPlayer]; // выдается вопрос из списка вопросов по сгенерированному номеру
        alert('Выберите правильный ответ на вопрос ' + questionRep[questionForPlayer] + '\n Для этого нажмите на соответствующую вопросу цифру.');
        const userAnswer = prompt('Варианты ответов: ' + answerVars.answerVarGenerator(question));
        if (answerChecker(userAnswer)) { // проверяет соответствие ответа правильному из списка правильных ответов
            alert('Правильно!');
            qNum++; // увеличивает счетчик вопросов
        } else {
            alert('Неверно, правильный ответ: ' + correctAnswers.qInd);
        }
    }
  },

  init() { // при запуске игры создает хранилище вопросов
    const questionRep = [
        "Лучший язык программирования?",
        "Кто придумал Python?",
        "Сколько башен в московском кремле?",
        "Какое расстояние до Луны в тыс. км?",
        "Какая температура кипения воды при давлении 750 мм.рт.ст?",
        "В какой из этих стран самый высокий ВВП на душу населения?"
      ];
  }
};

function qGenerator() {
    let qInd = Math.floor(Math.random() * qNum); // генерирует случайное число от 0 до qNum
    let question = questionRep[qInd]; // ищет в списке вопросов вопрос по сгенерированному индексу
    return question;
  };

game.init();
game.run();
