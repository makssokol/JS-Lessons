let mover = {
  getDirection() {
    const availableDirections = ["w", "s", "a", "d", "q", "e", "z", "c"];
    while (true) {
      let direction = prompt(
        "Для перемещения используйте буквы: w - вверх, s - вниз, a - влево, d - вправо, q - влево-вверх, e - вправо- вверх, z - влево-вниз, c - вправо-вниз."
      );
      if (direction == null) {
        return null;
      }
      if (!availableDirections.includes(direction)) {
        alert("Для перемещения используйте буквы w, a, s, d, q, e, z, c");
        continue;
      }
      return direction;
    }
  },
  getNextPosition(direction) {
    const nextPosition = {
      x: player.x,
      y: player.y
    };
    switch (direction) {
      case "a":
        nextPosition.x--;
        break;
      case "d":
        nextPosition.x++;
        break;
      case "w":
        nextPosition.y--;
        break;
      case "s":
        nextPosition.y++;
        break;
      case 'q':
          nextPosition.x--;
          nextPosition.y--;
          break;
        case 'e':
            nextPosition.x++;
            nextPosition.y--;
            break;
        case 'z':
            nextPosition.x--;
            nextPosition.y++;
            break;
        case 'c':
            nextPosition.x++;
            nextPosition.y++;
            break;
    }
    return nextPosition;
  }
};
