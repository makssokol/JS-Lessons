const config = {
    rowsCount: 10,
    colsCount: 10,
};