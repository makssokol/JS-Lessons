const player = {
  x: 0,
  y: 0,
  move(nextPoint) {
    if (
      nextPoint.x >= 0 &&
      nextPoint.x < 10 &&
      nextPoint.y >= 0 &&
      nextPoint.y < 10
    ) {
      this.x = nextPoint.x;
      this.y = nextPoint.y;
    } else {
      alert(
        "Вы не можете выйти за пределы игрового поля. Сделайте другой ход."
      );
      mover.getDirection();
    }
  }
};
